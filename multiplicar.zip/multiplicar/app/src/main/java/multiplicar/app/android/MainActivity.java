package multiplicar.app.android;

import android.app.*;
import android.os.*;



import android.app.*;
import android.os.*;


import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.view.KeyEvent.Callback;
import 	android.view.InputEvent;
import	android.view.KeyEvent;
import android.view.MenuInflater;
import 	android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewConfiguration;

import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;

import android.content.Context;


import android.app.Activity;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import java.lang.Object;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import android.text.TextUtils;

import android.view.View; 
import android.view.View.OnClickListener; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.TextView;
import java.lang.Object;
import java.lang.Throwable;
import java.lang.Exception;
import java.lang.Exception;
import java.io.IOException;
import android.webkit.WebView;
import android.view.KeyEvent.Callback;
import java.lang.Object;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.view.MenuItem;
import android.widget.Toast; 
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.util.List;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import 	android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.app.ListActivity;
import java.io.*;
import 
java.io.InputStream;
import java.io.FileInputStream;

import 	java.util.Collections;
import java.util.List;
import java.util.Comparator;
import java.util.Arrays;
import android.util.Base64;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import java.io.RandomAccessFile;
import 	java.io.RandomAccessFile;

import 	java.nio.charset.Charset;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.SimpleAdapter;




import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;


import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.*;

import android.graphics.Paint.Style;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.Bundle;
import android.widget.ImageView;


import java.lang.Object;
import java.util.Random;

import java.lang.Object;
import android.view.View;

import 
android.view.ViewGroup.LayoutParams;
import	android.view.ViewGroup.MarginLayoutParams;



import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;


import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.view.KeyEvent.Callback;
import 	android.view.InputEvent;
import	android.view.KeyEvent;
import android.view.MenuInflater;
import 	android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewConfiguration;

import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;

import android.content.Context;


import android.app.Activity;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;



import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import java.lang.Object;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import android.text.TextUtils;

import android.view.View; 
import android.view.View.OnClickListener; 
import android.widget.Button; 
import android.widget.EditText; 
import android.widget.TextView;
import java.lang.Object;
import java.lang.Throwable;
import java.lang.Exception;
import java.lang.Exception;
import java.io.IOException;
import android.webkit.WebView;
import android.view.KeyEvent.Callback;
import java.lang.Object;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.view.MenuItem;
import android.widget.Toast; 
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.util.List;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import 	android.content.Context;
import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;
import android.app.Activity;
import android.app.ListActivity;
import java.io.*;
import 
java.io.InputStream;
import java.io.FileInputStream;

import 	java.util.Collections;
import java.util.List;
import java.util.Comparator;
import java.util.Arrays;
import android.util.Base64;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import java.io.RandomAccessFile;
import 	java.io.RandomAccessFile;

import 	java.nio.charset.Charset;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.SimpleAdapter;




import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;


import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.*;

import android.graphics.Paint.Style;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.Bundle;
import android.widget.ImageView;


import java.lang.Object;
import java.util.Random;

import java.lang.Object;
//import android.view.View;

import 
android.view.ViewGroup.LayoutParams;
import	android.view.ViewGroup.MarginLayoutParams;

import android.app.Application;

import android.content.Context;



public class MainActivity extends Activity 
{
	private Context context;
	private ListView listview;

	String multiplicars ="0";
	String por="0";
	double d1=0.0;
	double d2=0.0;
	double d3=0.0;
int ddg=0;






























	private ArrayList<String> string1 = new ArrayList<String>();
	private ArrayList<String> string2 = new ArrayList<String>();





    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

		context = this;

		setTitle("multiplicar");

		int casas1=0;
		int casas2=0;
		int casas3=0;

		int ii;
		boolean b;
		try
		{
			multiplicars = System.getProperty("multiplicars.app.android.multiplicar").trim();

			por = System.getProperty("multiplicars.app.android.por").trim();

			d1 = Double.parseDouble(multiplicars);
			d2 = Double.parseDouble(por);

		}
		catch (Exception e)
		{

			d1 = 0.0;
			d2 = 0.0;
			multiplicars = "0";
			por = "0";
		}
		casas1 = multiplicars.indexOf(".");

		casas2 = por.indexOf(".");
		if (casas1 < 0)casas1 = 0;
		else casas1 = multiplicars.length() - casas1 - 1;
		if (casas2 < 0)casas2 = 0;
		else casas2 = por.length() - casas2 - 1;
		//setTitle(Integer.toString(casas1));
		casas3 = casas1 + casas2;
		d3 = d1 * d2;

		String multiplicarss=multiplicars.replaceAll("\\.", "");
		multiplicarss = multiplicarss.replaceAll("-", "");
		string1.add(String.format("%19s", multiplicars));
		string1.add(String.format("%20s", "X" + por));
		string1.add("----------------------");
		String h="";
		String s=func(por).replaceAll("\\.", "");

		double d4=0.0;
		for (int i=0;i < s.length();i++)
		{
			String t="" + s.charAt(i);
			try{
			d4 = Double.parseDouble(multiplicarss)  * Double.parseDouble(t);
			}catch(Exception e){
				d4=0;
				setTitle(e.toString());
				
			}
			String ss=(Double.toString(d4).replaceAll("\\.0", "") + h);
			ddg=ss.length();
			ss = ss.replaceAll("-", "");
			if (s.charAt(i) == '0')
			{
				ss = "";
				for (int f=0;f < multiplicars.length();f++)
				{
					ss = ss + "0";
				}
				ss = ss + h;
			}
			
			
			String sss=String.format("%19s", ss);
			if (casas3 > 0)
			{
				String hh=sss.substring(0, sss.length() - casas3);
				String hh1="." + sss.substring(sss.length() - casas3, sss.length());
				sss = hh + hh1;
				sss = String.format("%19s", sss);
			}
			
			sss=String.format("%20s", sss);
			
			string1.add(sss);
			h = h + "0";
		}
		string1.add("----------------------");
		String sd= Double.toString(d3).trim();
		int y=sd.indexOf(".");
		int gg=sd.length();
		if(y<0)y=gg;
		if(y<0 && casas3>0){
			
		sd=sd+".";
		
		}
		
		if(casas3>0)y++;
		
		sd = sd + "0000000000000000000";

		sd = sd.substring(0, y + casas3);


		sd = String.format("%19s", sd);

		sd = String.format("%20s", sd);
		if(ddg>7) sd="numero muito grande";
		string1.add(sd);
		//string2.add("");


        listview = (ListView) findViewById(R.id.listview);

        listview.setAdapter(new yourAdaptar(this, string1));

		listview.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view, int position, long id)
				{
					// When clicked, show a toast with the TextView text








					System.setProperty("multiplicars.app.android.multiplicar", multiplicars);

					System.setProperty("multiplicars.app.android.por", por);

					try
					{
						Intent intent = new Intent(context, main2activity.class);

						startActivity(intent);  

						finish(); 
					}
					catch (Exception e)
					{}

				}
			});



    }




	private String func(String ss)
	{
		int i;
		String s="";
		try
		{
			for (i = ss.length() - 1;i > -1;i--)
			{
				s = s + ss.charAt(i);
			}
		}
		catch (Exception e)
		{
			setTitle(e.toString());
		}
		return s;
	}



}


